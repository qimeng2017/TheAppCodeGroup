#import <UIKit/UIKit.h>

@interface BookmarkViewController : UITableViewController

@end
