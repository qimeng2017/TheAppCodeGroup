#import <UIKit/UIKit.h>

@interface ListViewController : UITableViewController

-(id)initWithURL:(NSString *)__url AndName:(NSString *)__name;

@end
