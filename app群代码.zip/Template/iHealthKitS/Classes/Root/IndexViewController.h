#import <UIKit/UIKit.h>

@interface IndexViewController : UITableViewController

@end
